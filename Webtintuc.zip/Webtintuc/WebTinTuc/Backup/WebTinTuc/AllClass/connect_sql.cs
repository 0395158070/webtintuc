﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace WebTinTuc.AllClass
{
    public class connect_sql
    {
        public string conn = WebConfigurationManager.ConnectionStrings["connect_tintuc"].ToString();
        public SqlConnection con;

        public void connect_data()
        {
            if (con == null) con = new SqlConnection(conn);
            if (con.State == ConnectionState.Closed) con.Open();
        }
        public void close_data()
        {
            if (con != null)
            {
                con.Close();
                con.Dispose();
            }
        }
    }

}