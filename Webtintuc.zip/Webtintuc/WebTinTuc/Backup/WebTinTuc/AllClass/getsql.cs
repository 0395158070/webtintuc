﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace WebTinTuc.AllClass
{
    public class getsql
    {
        private connect_sql con = new connect_sql();
        private string sql = null;
        private SqlCommand cmd;
        //Lấy thông tin Thành viên
        public int get_idtv(string tentv)
        {
            int id;
            sql = "select idtv from thanhvien where tentv='"+tentv+"'";
            con.connect_data();
            cmd = new SqlCommand(sql, con.con);
            id = (int)cmd.ExecuteScalar();
            return id;
        }
        public string get_tentv(int idtv)
        {
            sql = "select tentv from thanhvien where idtv='" + idtv + "'";
            con.connect_data();
            cmd = new SqlCommand(sql, con.con);
            string ten = (string)cmd.ExecuteScalar();
            return ten;
        }
        //Lấy thông tin bài viết
        public string get_tieude(int id)
        {
            sql = "select tieude from baiviet where idbv='" + id + "'";
            con.connect_data();
            cmd = new SqlCommand(sql, con.con);
            string st = (string)cmd.ExecuteScalar();
            return st;
        }
        public string get_link(int id)
        {
            sql = "select link from baiviet where idbv='" + id + "'";
            con.connect_data();
            cmd = new SqlCommand(sql, con.con);
            string st = (string)cmd.ExecuteScalar();
            return st;
        }
        public string get_tomtat(int id)
        {
            sql = "select tomtat from baiviet where idbv='" + id + "'";
            con.connect_data();
            cmd = new SqlCommand(sql, con.con);
            string st = (string)cmd.ExecuteScalar();
            return st;
        }
        public string get_noidung(int id)
        {
            sql = "select noidung from baiviet where idbv='" + id + "'";
            con.connect_data();
            cmd = new SqlCommand(sql, con.con);
            string st = (string)cmd.ExecuteScalar();
            return st;
        }
        public int get_idcd(int id)
        {
            sql = "select idcd from baiviet where idbv='" + id + "'";
            con.connect_data();
            cmd = new SqlCommand(sql, con.con);
            int st = (int)cmd.ExecuteScalar();
            return st;
        }
        //In <option> chủ đề
        public string op_chude(int idcd)
        {
            sql = "select * from chude";
            con.connect_data();
            cmd = new SqlCommand(sql, con.con);
            SqlDataReader re = cmd.ExecuteReader();
            string st="";
            while (re.Read())
            {
                if ((int)re.GetValue(0) == idcd)
                {
                    st = st + "<option value='" + re.GetValue(0) + "' selected>" + re.GetValue(1) + "</option>";
                }
                else
                {
                    st = st + "<option value='" + re.GetValue(0) + "'>" + re.GetValue(1) + "</option>";
                }
            }
            re.Close();
            return st;
        }
    }
}