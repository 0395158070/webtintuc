﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace WebTinTuc.AllClass
{
    public class kt_admin
    {
        public bool kiemtra(string us)
        {
            connect_sql con=new connect_sql();
            con.connect_data();
            //int kt;
            string sql = "select admin from thanhvien where tentv='" + us + "'";
            SqlCommand cmd = new SqlCommand(sql, con.con);
            bool kt = (bool)cmd.ExecuteScalar();
            return kt;
        }
    }
}