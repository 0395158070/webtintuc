﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using WebTinTuc.AllClass;

namespace WebTinTuc
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            connect_sql con = new connect_sql();
            con.connect_data();
            string sql = "select count(idbv) from baiviet";
            SqlCommand cmd = new SqlCommand(sql, con.con);
            SqlDataReader re;
            //Phân trang
            //Tổng số tin tức
            int total = (int)cmd.ExecuteScalar();

            //Trang hiện tại và Limit
            int current_page;
            if (Request.QueryString.Get("p") == null)
                current_page = 1;
            else current_page = Convert.ToInt32(Request.QueryString.Get("p"));
            int limit = 5;

            //Tổng số Page và Start
            int total_page;
            if ((total % limit) != 0) total_page = (total / limit) + 1;
            else total_page = total / limit;
            //
            if (current_page > total_page){
            current_page = total_page;
            }
            if (current_page < 1){
                current_page = 1;
            }
            int start = ((current_page - 1) * limit)+1;
            int end = start + limit - 1;
            //
            //sql = "select top "+start+", "+limit+" * from baiviet";
            sql = "select * from (select *, ROW_NUMBER() OVER (ORDER BY idbv desc) as row from baiviet) bv where bv.row>=" + start + " and bv.row<=" + end;
            cmd = new SqlCommand(sql, con.con);
            re = cmd.ExecuteReader();
            string tt;
            while(re.Read())
            {
                tt="<div class='w3-container w3-cell'><img src='"+re.GetValue(2)+"' width='150px' /></div>";
                tt = tt + "<div class='w3-cell w3-container'><b><a href='tintuc.aspx?id="+re.GetValue(0)+"'>"+re.GetValue(1)+"</a></b><br/>";
                tt = tt + re.GetValue(3)+"</div><br/><hr/>";
                tintuc.Text = tintuc.Text + tt;
            }
            re.Close();

            //Hiển thị phân trang
            phantrang.Text="";
            for (int i = 1; i <= total_page; i++){
                // Nếu là trang hiện tại thì hiển thị thẻ span
                // ngược lại hiển thị thẻ a
                if (i == current_page){
                    phantrang.Text=phantrang.Text+ "<span class='w3-button w3-red'>"+i+"</span> ";
                }
                else{
                    phantrang.Text = phantrang.Text + "<a href='Home.aspx?p=" + i + "'><span class='w3-button w3-green'>" + i + "</span></a> ";
                }
            }
        }
    }
}