﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using WebTinTuc.AllClass;

namespace WebTinTuc
{
    public partial class mHome : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string u;
            u = (string)Session["user"];
            if (u != null)
            {
                top.Text = "Xin chào! <b>" + u + "</b> (<a href='site/dang_xuat.aspx'>Logout</a>)";
                kt_admin kt = new kt_admin();
                bool gt = kt.kiemtra(u);
                if (gt == true) top.Text = top.Text + "<br/><a style='color:green' href='ql_tintuc.aspx'>Quản lý Website</a>";
            }
            else
            {
                top.Text = "<a href='dang_ky.aspx'>Đăng Ký</a> | <a href='dang_nhap.aspx'>Đăng Nhập</a>";
            }
            
            //
            //hiển thị tin nổi bật
            connect_sql con = new connect_sql();
            con.connect_data();
            string sql = "select top 5 * from baiviet order by luotxem desc";
            SqlCommand cmd = new SqlCommand(sql, con.con);
            SqlDataReader re = cmd.ExecuteReader();
            string tt;
            while (re.Read())
            {
                tt = "<p><a href='tintuc.aspx?id="+re.GetValue(0)+"'>" + re.GetValue(1) + "</a><p>";
                tinnoibat.Text = tinnoibat.Text + tt;
            }
            re.Close();

            //Hiển thị thanh MENU
            sql = "select * from chude";
            cmd = new SqlCommand(sql, con.con);
            re = cmd.ExecuteReader();
            
            while (re.Read())
            {
                tt = "<div class='w3-bar-item w3-button'><a href='chude.aspx?id=" + re.GetValue(0) + "'>" + re.GetValue(1) + "</a></div>";
                menu.Text = menu.Text + tt;
            }
            if (Request.Form.Get("search") != null)
            {
                string key=Request.Form.Get("key");
                Response.Redirect("timkiem.aspx?key=" + key+"&search=true");
            }
        }
    }
}