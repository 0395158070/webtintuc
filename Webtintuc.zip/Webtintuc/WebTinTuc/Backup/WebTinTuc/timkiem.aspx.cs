﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using WebTinTuc.AllClass;

namespace WebTinTuc
{
    public partial class timkiem : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!IsPostBack)
            //{
                string key="";
                if (Request.QueryString.Get("search") != null || Request.Form.Get("search") != null)
                {
                    if (Request.Form.Get("search") != null)
                    {
                        key = Request.Form.Get("key");
                        Response.Redirect("timkiem.aspx?key=" + key + "&search=true");
                    }
                    
                    if (Request.QueryString.Get("search") != null)
                        key = Request.QueryString.Get("key");
                    //
                    if (key != "" & key!= " ")
                    {
                        connect_sql con = new connect_sql();
                        con.connect_data();
                        string sql = "select * from baiviet where tieude like N'%" + key + "%' or tomtat like N'%" + key + "%' or noidung like N'%" + key + "%' order by idbv desc";
                        SqlCommand cmd = new SqlCommand(sql, con.con);
                        SqlDataReader re = cmd.ExecuteReader();
                        string tt;
                        tukhoa.Text = key;
                        while (re.Read())
                        {
                            tt = "<div class='w3-container w3-cell'><img src='" + re.GetValue(2) + "' width='150px' /></div>";
                            tt = tt + "<div class='w3-cell w3-container'><b><a href='tintuc.aspx?id=" + re.GetValue(0) + "'>" + re.GetValue(1) + "</a></b><br/>";
                            tt = tt + re.GetValue(3) + "</div><br/><hr/>";
                            kqtk.Text = kqtk.Text + tt;
                        }
                    }
                }
            //}
        }
    }
}