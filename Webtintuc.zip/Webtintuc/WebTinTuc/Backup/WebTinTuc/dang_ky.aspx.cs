﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//using System.Data;
using System.Data.SqlClient;
//using System.Web.Configuration;
using WebTinTuc.AllClass;

namespace WebTinTuc
{
    public partial class dang_ky : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
            //lb_sotv.Text = "<span><b class='w3-blue'>1"+sotv.ToString()+"</b><span>";
            if (Request.Form.Get("register") != null)
            {
                string user, pass, email;
                user = Request.Form.Get("username");
                pass = Request.Form.Get("pass1");
                email = Request.Form.Get("email");
                connect_sql con = new connect_sql();
                con.connect_data();
                string sql_kt = "select count(tentv) from thanhvien where tentv='" + user + "'";
                SqlCommand cmd = new SqlCommand(sql_kt, con.con);
                int kt = (int)cmd.ExecuteScalar();
                if (kt == 0)
                {
                    string sql = "insert into thanhvien(tentv, matkhau, email) values('" + user + "','" + pass + "','" + email + "')";
                    cmd = new SqlCommand(sql, con.con);
                    cmd.ExecuteNonQuery();
                    alert.Text = "Đăng ký thành công. Chuyển tới trang => <a style='color:blue' href='dang_nhap.aspx'>Đăng Nhập</a>";
                }
                else
                {
                    alert.Text = "Error: Tên tài khoản này đã có người sử dụng!";
                }
            }

        }
    }
}