﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using WebTinTuc.AllClass;

namespace WebTinTuc.site
{
    public partial class chude_delete : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string u = (string)Session["user"];
            if (u == null) Response.Redirect("../Home.aspx");
            else
            {
                kt_admin kt = new kt_admin();
                if (kt.kiemtra(u))
                {
                    int idcd = Convert.ToInt32(Request.QueryString.Get("id"));
                    connect_sql con = new connect_sql();
                    con.connect_data();

                    //xóa hết tin tức trong chủ đề này
                    string sql = "delete from baiviet where idcd='"+idcd+"'";
                    SqlCommand cmd = new SqlCommand(sql, con.con);
                    cmd.ExecuteNonQuery();
                    //xóa chủ đề
                    sql = "delete from chude where idcd='" + idcd + "'";
                    cmd = new SqlCommand(sql, con.con);
                    cmd.ExecuteNonQuery();
                    Response.Redirect("../ql_chude.aspx");
                }
                Response.Redirect("../Home.aspx");
            }
        }
    }
}