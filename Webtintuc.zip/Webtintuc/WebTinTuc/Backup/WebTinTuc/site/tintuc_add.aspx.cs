﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using WebTinTuc.AllClass;

namespace WebTinTuc.site
{
    public partial class tintuc_add : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Hiển thị <option> chủ để
            connect_sql con = new connect_sql();
            con.connect_data();
            string sql = "select * from chude";
            SqlCommand cmd = new SqlCommand(sql, con.con);
            SqlDataReader re = cmd.ExecuteReader();
            string tt;
            while (re.Read())
            {
                tt = "<option value='" + re.GetValue(0) + "'>" + re.GetValue(1) + "</option>";
                chude.Text = chude.Text + tt;
            }
            re.Close();
            //
            //Thêm tin tức
            if (Request.Form.Get("tintuc_add") != null)
            {
                string tieude, tomtat, noidung;
                string link = "/image/technews.jpg";
                int idcd, idtv;
                string ngayviet = DateTime.Now.ToString();
                tieude = Request.Form.Get("tieude");
                tomtat = Request.Form.Get("tomtat");
                noidung = HttpUtility.HtmlEncode(Request.Form.Get("noidung"));
                idcd = Convert.ToInt32(Request.Form.Get("chude"));
                getsql getidtv = new getsql();
                idtv=getidtv.get_idtv((string)Session["user"]);
                //Upload ảnh lên server
                if (fup.HasFile)
                {
                    link = "/image/" + fup.FileName;
                    string fName = "../image/" + fup.FileName;
                    string fPath = MapPath(fName);
                    fup.SaveAs(fPath);
                }
                sql = "insert into baiviet(tieude, link, tomtat, noidung, idcd, idtv, ngayviet) values(N'"+tieude+"', '"+link+"', N'"+tomtat+"', N'"+noidung+"', '"+idcd+"', '"+idtv+"', '"+ngayviet+"')";
                cmd = new SqlCommand(sql, con.con);
                cmd.ExecuteNonQuery();
                Response.Redirect("../ql_tintuc.aspx");
            }
        }

    }
}