﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using WebTinTuc.AllClass;

namespace WebTinTuc.site
{
    public partial class chude_update : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int idcd = Convert.ToInt32(Request.QueryString.Get("id"));
            idchude.Text = "<b style='color: red'>" + idcd.ToString() + "</b>";
            connect_sql con = new connect_sql();
            con.connect_data();
            string sql="select tencd from chude where idcd='"+idcd+"'";
            SqlCommand cmd = new SqlCommand(sql, con.con);
            string tencd = (string)cmd.ExecuteScalar();
            tenchude.Text = "<input type='text' name='tencd' value='" + tencd + "' class='w3-input' />";
            if (Request.Form.Get("chude_update") != null)
            {
                tencd = Request.Form.Get("tencd");
                sql = "update chude set tencd=N'" + tencd + "' where idcd='" + idcd + "'";
                cmd = new SqlCommand(sql, con.con);
                cmd.ExecuteNonQuery();
                Response.Redirect("../ql_chude.aspx");
            }

        }
    }
}