﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using WebTinTuc.AllClass;

namespace WebTinTuc.site
{
    public partial class tintuc_update : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Hiển thị thông tin cũ của tin tức
            int idbv = Convert.ToInt32(Request.QueryString.Get("id"));
            getsql gs = new getsql();
            tieude.Text = "<input type='text' class='w3-input w3-border' name='tieude' value='"+gs.get_tieude(idbv)+"' />";
            image.ImageUrl = ".."+gs.get_link(idbv);
            tomtat.Text=gs.get_tomtat(idbv);
            noidung.Text = gs.get_noidung(idbv);
            int idcd = gs.get_idcd(idbv);
            chude.Text = gs.op_chude(idcd);

            //Sửa tin tức
            if (Request.Form.Get("tintuc_update") != null)
            {
                string tieude_new, tomtat_new, noidung_new;
                string link = gs.get_link(idbv);
                int idcd_new, idtv_new;
                tieude_new = Request.Form.Get("tieude");
                tomtat_new = Request.Form.Get("tomtat");
                noidung_new = HttpUtility.HtmlEncode(Request.Form.Get("noidung"));
                idcd_new = Convert.ToInt32(Request.Form.Get("chude"));
                getsql getidtv = new getsql();
                idtv_new = getidtv.get_idtv((string)Session["user"]);
                //Upload ảnh lên server
                if (fup.HasFile)
                {
                    link = "/image/" + fup.FileName;
                    string fName = "../image/" + fup.FileName;
                    string fPath = MapPath(fName);
                    fup.SaveAs(fPath);
                }
                connect_sql con = new connect_sql();
                con.connect_data();
                string sql = "update baiviet set tieude=N'" + tieude_new + "', link='" + link + "', tomtat=N'" + tomtat_new + "', noidung=N'" + noidung_new + "', idcd='" + idcd_new + "', idtv='" + idtv_new + "' where idbv='" + idbv + "'";
                SqlCommand cmd = new SqlCommand(sql, con.con);
                cmd.ExecuteNonQuery();
                Response.Redirect("../ql_tintuc.aspx");
            }

        }
    }
}