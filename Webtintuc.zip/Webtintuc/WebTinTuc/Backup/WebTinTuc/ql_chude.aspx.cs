﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using WebTinTuc.AllClass;

namespace WebTinTuc
{
    public partial class ql_chude : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            connect_sql con = new connect_sql();
            con.connect_data();
            string sql;
            SqlCommand cmd;
            if (!IsPostBack)
            {
                con = new connect_sql();
                con.connect_data();
                sql = "select * from chude order by idcd desc";
                cmd = new SqlCommand(sql, con.con);
                SqlDataReader re = cmd.ExecuteReader();
                string tt;
                while (re.Read())
                {
                    tt = "<tr><td>" + re.GetValue(0) + "</td>";
                    tt = tt + "<td><a href='chude.aspx?id="+re.GetValue(0)+"'>" + re.GetValue(1) + "</a></td>";
                    tt = tt + "<td><a href='site/chude_update.aspx?id=" + re.GetValue(0) + "'>Sửa</a> | <a href='site/chude_delete.aspx?id=" + re.GetValue(0) + "'>Xóa</a> </td></tr>";
                    chude.Text = chude.Text + tt;
                }
                re.Close();
            }
            //Thêm chủ đề
            if (Request.Form.Get("chude_add") != null)
            {
                string tencd = Request.Form.Get("tencd");
                sql = "insert into chude(tencd) values(N'" + tencd + "')";
                cmd = new SqlCommand(sql, con.con);
                cmd.ExecuteNonQuery();
                Response.Redirect("ql_chude.aspx");
            }
            
        }
    }
}