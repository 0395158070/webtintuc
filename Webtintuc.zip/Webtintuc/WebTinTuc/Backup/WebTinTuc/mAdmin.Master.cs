﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebTinTuc.AllClass;

namespace WebTinTuc
{
    public partial class mAdmin : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string u;
            u = (string)Session["user"];
            if (u != null)
            {
                top.Text = "Xin chào! <b>" + u + "</b> (<a href='site/dang_xuat.aspx'>Logout</a>)";
                kt_admin kt = new kt_admin();
                bool gt = kt.kiemtra(u);
                if (gt == true) top.Text = top.Text + "<br/><a style='color: green' href='ql_tintuc.aspx'>Quản lý Website</a>";
            }
            else
            {
                Response.Redirect("Home.aspx");
            }
            
        }
    }
}