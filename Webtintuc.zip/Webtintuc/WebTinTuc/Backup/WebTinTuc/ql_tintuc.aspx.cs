﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using WebTinTuc.AllClass;

namespace WebTinTuc
{
    public partial class ql_tintuc : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            connect_sql con = new connect_sql();
            con.connect_data();
            string sql = "select * from baiviet order by idbv desc";
            SqlCommand cmd = new SqlCommand(sql, con.con);
            SqlDataReader re = cmd.ExecuteReader();
            string tt;
            while (re.Read())
            {
                tt="<tr><td>"+re.GetValue(0)+"</td><td><a href='tintuc.aspx?id="+re.GetValue(0)+"'>"+re.GetValue(1)+"</a></td>";
                tt = tt + "<td><a href='site/tintuc_update.aspx?id=" + re.GetValue(0) + "'>Sửa</a> | <a href='site/tintuc_delete.aspx?id=" + re.GetValue(0) + "'>Xóa</a>";
                tt = tt + "</td></tr>";
                tintuc.Text = tintuc.Text + tt;
            }
        }
    }
}