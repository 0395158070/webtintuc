﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using WebTinTuc.AllClass;

namespace WebTinTuc
{
    public partial class tintuc : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int idbv = Convert.ToInt32(Request.QueryString.Get("id"));
            connect_sql con = new connect_sql();
            con.connect_data();
            string sql = "select * from baiviet where idbv='" + idbv + "'";
            SqlCommand cmd = new SqlCommand(sql, con.con);
            SqlDataReader re = cmd.ExecuteReader();
            getsql gs = new getsql();
            while (re.Read())
            {
                nguoiviet.Text = gs.get_tentv((int)re.GetValue(6));
                ngayviet.Text = re.GetValue(7).ToString();
                image.Text = "<img src='" + re.GetValue(2) + "' width='200px' />";
                tieude.Text = "<h3><b>" + re.GetValue(1) + "</b></h3>";
                tomtat.Text = "<p><b>" + re.GetValue(3) + "</b></p>";
                noidung.Text = HttpUtility.HtmlDecode(re.GetValue(4).ToString());
                luotxem.Text = "(Lượt xem: " + re.GetValue(8) + " )";
            }
            re.Close();

            //Tăng lượt xem
            sql = "update baiviet set luotxem=luotxem+1 where idbv='" + idbv + "'";
            cmd = new SqlCommand(sql, con.con);
            cmd.ExecuteNonQuery();
            //Hiển thị bình luận
            sql = "select * from binhluan where idbv=" + idbv + " order by idbl desc";
            cmd = new SqlCommand(sql, con.con);
            re = cmd.ExecuteReader();
            string tentv, st;
            while (re.Read())
            {
                tentv = gs.get_tentv((int)re.GetValue(2));
                st = "<b>" + tentv + "</b>: " + re.GetValue(1) + "<br/><br/>";
                hienthibl.Text = hienthibl.Text + st;
            }
            re.Close();

            //Bình luận
            if (Session["user"] != null)
            {
                //Hiển thị nút bình luận, khi user đã đăng nhập
                binhluan.Text = "<textarea rows='3' cols='15' class='w3-input w3-border' name='noidungbl'></textarea>";
                binhluan.Text = binhluan.Text + "<br/><input type='submit' name='bl' value='Bình luận' class='w3-button w3-green' />";
                //Thêm bình luận
                if (Request.Form.Get("bl") != null)
                {
                    string noidungbl=Request.Form.Get("noidungbl");
                    int idtv = gs.get_idtv(Session["user"].ToString());
                    sql = "insert into binhluan(noidungbl, idtv, idbv) values(N'"+noidungbl+"','"+idtv+"','"+idbv+"')";
                    cmd = new SqlCommand(sql, con.con);
                    cmd.ExecuteNonQuery();
                    Response.Redirect("tintuc.aspx?id=" + idbv + "#linkbl");
                }
            }
        }
    }
}