﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using WebTinTuc.AllClass;

namespace WebTinTuc
{
    public partial class chude : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int idcd = Convert.ToInt32(Request.QueryString.Get("id"));
            connect_sql con = new connect_sql();
            con.connect_data();
            string sql = "select tencd from chude where idcd='"+idcd+"'";
            SqlCommand cmd = new SqlCommand(sql, con.con);
            string tencd = (string)cmd.ExecuteScalar();
            cd.Text = tencd+"<hr/>";

            //Hiển thị tin tức thuộc chủ đề
            sql = "select * from baiviet where idcd='"+idcd+"' order by idbv desc";
            cmd = new SqlCommand(sql, con.con);
            SqlDataReader re = cmd.ExecuteReader();
            string st;
            while (re.Read())
            {
                st = "<div class='w3-container w3-cell'><img src='" + re.GetValue(2) + "' width='150px' /></div>";
                st = st + "<div class='w3-cell w3-container'><b><a href='tintuc.aspx?id=" + re.GetValue(0) + "'>";
                st = st +re.GetValue(1) + "</a></b><br/>";
                st = st + re.GetValue(3) + "</div><br/><hr/>";
                tt.Text = tt.Text + st;
            }
        }
    }
}