﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using WebTinTuc.AllClass;

namespace WebTinTuc
{
    public partial class dang_nhap : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Form.Get("login") != null)
            {
                string user, pass;
                user = Request.Form.Get("username");
                pass = Request.Form.Get("pass");
                connect_sql con = new connect_sql();
                con.connect_data();
                string sql_kt = "select count(tentv) from thanhvien where tentv='" + user + "' and matkhau='" + pass + "'";
                SqlCommand cmd = new SqlCommand(sql_kt, con.con);
                int kt = (int)cmd.ExecuteScalar();
                if (kt == 0)
                {
                    alert.Text = "Error: Sai thông tin đăng nhập!";
                }
                else
                {
                    Session["user"] = user;
                    kt_admin ktadmin = new kt_admin();
                    if (ktadmin.kiemtra(user))
                    {
                        Response.Redirect("ql_tintuc.aspx");
                    }
                    else
                    {
                        Response.Redirect("Home.aspx");
                    }
                }
            }
        }
    }
}