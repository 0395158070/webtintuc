﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace WebTinTuc.AllClass
{
    public class connect_sql
    {   
        // Lấy chuỗi kết nối trong web.config
        public string conn = WebConfigurationManager.ConnectionStrings["connect_tintuc"].ToString();
        // Khai báo biến sqlconnection
        public SqlConnection con;

        public void connect_data() // Thủ tục mở kết nối
        {
            if (con == null) con = new SqlConnection(conn);
            if (con.State == ConnectionState.Closed) con.Open();
        }
        public void close_data() // Thủ tục đóng kết nối
        {
            if (con != null)
            {
                // giải phóng kết nối
                con.Close();
                con.Dispose();
            }
        }
    }

}